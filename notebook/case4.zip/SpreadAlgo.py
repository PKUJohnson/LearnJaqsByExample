# encoding: utf-8

from __future__ import print_function
from __future__ import absolute_import

from jaqs.trade import EventDrivenStrategy
from jaqs.trade import common, model

class SpreadAlgo(EventDrivenStrategy):
    """"""
    def __init__(self):
        super(SpreadAlgo, self).__init__()
        self.symbol = ''
        
        self.tick_sizes = []
        
        self.signal = 0.0
        
        self.pos = 0
        self.pos1 = 0
        self.pos2 = 0
        
        self.tick1 = None
        self.tick2 = None
        
    def init_from_config(self, props):
        super(SpreadAlgo, self).init_from_config(props)
        self.symbol       = props.get('symbol')
        self.tick_sizes   = props.get('tick_sizes')
        self.open_spread  = props.get('open_spread')
        self.close_spread = props.get('close_spread')
        
        self.s1, self.s2 = self.symbol.split(',')
        
        #self.pos = self.ctx.pm.get_pos(self.s1)
        
    def on_cycle(self):
        pass
    
    def long_spread(self, mid1, mid2, n=1):
        self.ctx.trade_api.place_order(self.s1, common.ORDER_ACTION.BUY,   mid1 + n * self.tick_sizes[0], 1)
        self.ctx.trade_api.place_order(self.s2, common.ORDER_ACTION.SHORT, mid2 - n * self.tick_sizes[1], 1)

    def short_spread(self, mid1, mid2, n=1):

        self.ctx.trade_api.place_order(self.s2, common.ORDER_ACTION.BUY,   mid2 + n * self.tick_sizes[1], 1)
        self.ctx.trade_api.place_order(self.s1, common.ORDER_ACTION.SHORT, mid1 - n * self.tick_sizes[0], 1)

    def on_tick(self, tick):
        if tick.symbol == self.s1:
            self.tick1 = tick
        elif tick.symbol == self.s2:
            self.tick2 = tick
        
        if self.tick1 is None or self.tick2 is None:
            return
        
        mid1 = (self.tick1.askprice1 + self.tick1.bidprice1) / 2
        mid2 = (self.tick2.askprice1 + self.tick2.bidprice1) / 2
        
        spread = mid1 - mid2
        print("spread = ", spread)
        
        if spread > self.open_spread:
            if self.pos == 0 :
                self.short_spread(round(mid1, 0), round(mid2, 0), 5)
                self.pos = 1
        
        elif spread < self.close_spread:
            if self.pos > 0:
                self.long_spread(round(mid1, 0), round(mid2, 0), 5)    
                self.pos = 0
        
    def on_bar(self, quote_dic):
        pass
            
    def on_trade(self, ind):
        self.pos1 = self.ctx.pm.get_pos(self.s1)
        self.pos2 = self.ctx.pm.get_pos(self.s2)
        #self.pos = self.pos1


