# encoding: utf-8

from __future__ import print_function
from __future__ import absolute_import

from jaqs.trade import model

from jaqs.data import RemoteDataService
from jaqs.trade import EventLiveTradeInstance
from jaqs.trade import PortfolioManager
from jaqs.trade import RealTimeTradeApi

from SpreadAlgo import SpreadAlgo

data_config = {
  "remote.data.address": "tcp://data.tushare.org:8910",
  "remote.data.username": "18612562791",
  "remote.data.password": "eyJhbGciOiJIUzI1NiJ9.eyJjcmVhdGVfdGltZSI6IjE1MTI2NTczNDEzMDQiLCJpc3MiOiJhdXRoMCIsImlkIjoiMTg2MTI1NjI3OTEifQ.gGA4qLXQ9KgkN_KntXSK8dVpzBHMEaIiGXX3JpALTpc"
}

trade_config = {
  "remote.trade.address": "tcp://127.0.0.1:8901",
  "remote.trade.username": "username",
  "remote.trade.password": "password"
}

def run_strategy():
    tapi = RealTimeTradeApi(trade_config, prod_type = "jaqs")
    ins = EventLiveTradeInstance()
    
    ds    = RemoteDataService()
    strat = SpreadAlgo()
    pm    = PortfolioManager()
    
    props = {
        "symbol"       : "rb1805.SHF,rb1810.SHF",
        "tick_sizes"   : [1.0, 1.0],
        "open_spread"  : 200.5,
        "close_spread" : 200
    }
    
    props.update(data_config)
    props.update(trade_config)
    
    context = model.Context(data_api=ds, trade_api=tapi, instance=ins,
                            strategy=strat, pm=pm)
    
    ins.init_from_config(props)
    
    ds.subscribe(props['symbol'])
    
    ins.run()


if __name__ == "__main__":
    run_strategy()
